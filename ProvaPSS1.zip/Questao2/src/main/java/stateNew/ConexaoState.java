/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stateNew;

/**
 *
 * @author TgP
 */
public abstract class ConexaoState {

    public abstract void enviarRequisicao(Requisicao requisicao, Conexao cx);

    public abstract Resposta receberResposta(Conexao cx, Resposta resposta);

}
