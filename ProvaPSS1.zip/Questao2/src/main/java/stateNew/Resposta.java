/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stateNew;

/**
 *
 * @author TgP
 */
public class Resposta {

    private Usuario remetente;
    private String resposta;

    public Resposta(Usuario remetente, String resposta) {
        this.remetente = remetente;
        this.resposta = resposta;
    }

    public Resposta(Usuario remetente) {
        this.remetente = remetente;
    }

    public Usuario getRemetente() {
        return remetente;
    }

    public void setRemetente(Usuario remetente) {
        this.remetente = remetente;
    }

    public String getResposta() {
        return resposta;
    }

    public void setResposta(String resposta) {
        this.resposta = resposta;
    }

    public String getNomeRemente() {
        return this.remetente != null ? this.remetente.getNome() : null;
    }

}
