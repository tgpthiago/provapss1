/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stateNew;

/**
 *
 * @author TgP
 */
public class Conectado extends ConexaoState {

    public Conectado() {
        System.out.println("Conectado!");
    }

    @Override
    public void enviarRequisicao(Requisicao requisicao, Conexao cx) {
        System.out.println("Requisicao enviada!");
        System.out.println(requisicao.getNomeRemente() + ": " + requisicao.getMensagem());
        cx.aguardarResposta();
    }

    @Override
    public Resposta receberResposta(Conexao cx, Resposta resposta) {
        System.out.println("Nenhuma requisição enviada!");
        return null;
    }
}
