/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stateNew;

/**
 *
 * @author TgP
 */
public class AguardandoResposta extends ConexaoState {

    public AguardandoResposta() {
    }

    @Override
    public void enviarRequisicao(Requisicao requisicao, Conexao cx) {
        System.out.println("Não é possivel enviar outra requisição, pois está aguardando resposta!");
    }

    @Override
    public Resposta receberResposta(Conexao cx, Resposta res) {
        System.out.println("Resposta recebida!");
        System.out.println(res.getNomeRemente() + ": " + res.getResposta());
        cx.conectar();
        return res;
    }

}
