/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stateNew;
/**
 *
 * @author TgP
 */
public class Conexao {
    private ConexaoState estado;

    public Conexao() {
        this.estado = new Desconectado();
    }
    
    public void conectar() {
        if (estado instanceof Desconectado) {
            estado = new Conectado();
        } else if (estado instanceof AguardandoResposta) {
            estado = new Conectado();
        }
    }

    public void desconectar() {
        if (estado instanceof Desconectado)
            System.out.println("Já está desconectado!");
        else
            estado = new Desconectado();
    }
    
    public void aguardarResposta(){
        estado = new AguardandoResposta();
    }

    public ConexaoState getEstado() {
        return estado;
    }
    
    public void enviarRequisicao(Requisicao req){
        this.estado.enviarRequisicao(req, this);
    }
    
    public void receberResposta(Resposta resposta){
        this.estado.receberResposta(this, resposta);
    }
    
}
