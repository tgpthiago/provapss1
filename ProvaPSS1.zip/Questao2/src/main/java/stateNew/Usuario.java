/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stateNew;

/**
 *
 * @author TgP
 */
public class Usuario {

    private String nome;

    public Usuario(String nome) {
        this.nome = nome;
    }

    public Usuario() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
