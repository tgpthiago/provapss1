/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stateNew;

/**
 *
 * @author TgP
 */
public class Requisicao {

    private Usuario remetente;
    private String mensagem;

    public Requisicao(Usuario remetente, String mensagem) {
        this.remetente = remetente;
        this.mensagem = mensagem;
    }

    public Usuario getRemetente() {
        return remetente;
    }

    public void setRemetente(Usuario remetente) {
        this.remetente = remetente;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
    
    public String getNomeRemente() {
        return this.remetente != null ? this.remetente.getNome() : null;
    }

}
