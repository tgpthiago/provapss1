/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.state;

/**
 *
 * @author TgP
 */
public class Desconectado extends AbstractConexaoState{
    private Usuario usuario;
   
    public Desconectado(Usuario usuario) {
        this.usuario = usuario;
        this.usuario.setDesligado(true);
    }

    @Override
    public void conectar() {
       usuario.setEstado(new Conecta(usuario)); 
    }

    
}
