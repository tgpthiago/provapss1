/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.state;

/**
 *
 * @author TgP
 */
public class Usuario {
    private AbstractConexaoState estado;
    private boolean desligado;
    private String nome;
    
    public Usuario(String nome){
        this.nome = nome;
        estado = new Desconectado(this);
    }
    
    public void setEstado(AbstractConexaoState estado){
        this.estado = estado;
    }
    
    public void conectar() throws Exception{
        estado.conectar();
    }
    
    public void desconectar() throws Exception{
        estado.desconectar();
    }

    public void setDesligado(boolean desligado) {
        this.desligado = desligado;
    }
    
    public boolean isDesligado() {
        return desligado;
    }

    public void imprimirDesligado(){
        if(isDesligado() == true)
            System.out.println("Usuario Desligado!");
        else
            System.out.println("Usuario Ligado!");
    }

    public String getNome() {
        return nome;
    }    
}

    
