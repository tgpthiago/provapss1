/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.state;

/**
 *
 * @author TgP
 */
public class Resposta {
    private String resposta;
    
    public void resposta(Usuario remetente, String resposta, Usuario destinatario){
        if(remetente.isDesligado() == true){
            System.out.println(remetente.getNome()+ ": Impossivel enviar resposta, pois seu usuario está desligado!");    
        }
        else if(destinatario.isDesligado() == true){
            System.out.println("Impossivel enviar resposta! Destinatario " +destinatario.getNome()+ " desligado!");
        }else{
            this.resposta = resposta;
            System.out.println(remetente.getNome() + ": " +resposta);
        }
    }
}

