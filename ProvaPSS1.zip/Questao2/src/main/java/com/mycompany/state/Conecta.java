/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.state;

/**
 *
 * @author TgP
 */
public class Conecta extends AbstractConexaoState {
    private Usuario usuario;

    public Conecta(Usuario usuario) {
        this.usuario = usuario;
        this.usuario.setDesligado(false);
        System.out.println(usuario.getNome()+ " Conectado!");
    }

    @Override
    public void desconectar() {
         usuario.setEstado(new Desconectado(usuario));
         
    }
    
   
}
