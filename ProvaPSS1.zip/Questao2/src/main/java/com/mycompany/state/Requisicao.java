/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.state;

/**
 *
 * @author TgP
 */
public class Requisicao {
    private String mensagem;
    
    
    
    public void Requisicao(Usuario remetente, String mensagem, Usuario destinatario){
        if(remetente.isDesligado() == true){
            System.out.println(remetente.getNome()+ ": Impossivel enviar requisição, pois seu usuario está desligado!");    
        }
        else if(destinatario.isDesligado() == true){
            System.out.println( "Impossivel enviar requisição! Destinatario " +destinatario.getNome()+ " desligado!");
        }else{
            this.mensagem = mensagem;
            System.out.println(remetente.getNome() + ": " +mensagem);
        }
    }
}
