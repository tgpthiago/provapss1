/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.state;

/**
 *
 * @author TgP
 */
public class CaixaDeMensagem {
    private boolean existeMensagem = false;
    
    public void enviarMensagem(Usuario remetente, Usuario destinatario, String mensagem){
        if(remetente.isDesligado() == true){
            System.out.println(remetente.getNome()+ ": Impossivel enviar resposta, pois seu usuario está desligado!");
            
        }
        
        else{
            System.out.println("-----------------"); 
            Requisicao req = new Requisicao();
            req.Requisicao(remetente, mensagem ,destinatario);
            if(destinatario.isDesligado()== false)
            existeMensagem = true;
        }
    }
    
    public void responderMensagem(Usuario remetente, Usuario destinatario, String mensagem){
        if(existeMensagem == false){
            System.out.println("Não existe mensagem para responder!");
            System.out.println("-----------------");
        }
        else{Resposta res = new Resposta();
        res.resposta(remetente, mensagem,destinatario);
        existeMensagem = false;
        System.out.println("-----------------");
        }
    }
}
