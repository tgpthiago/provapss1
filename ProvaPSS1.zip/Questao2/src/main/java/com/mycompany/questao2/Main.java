/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.questao2;

import com.mycompany.state.AbstractConexaoState;
import com.mycompany.state.CaixaDeMensagem;
import com.mycompany.state.Requisicao;
import com.mycompany.state.Resposta;
import com.mycompany.state.Usuario;

/**
 *
 * @author TgP
 */
public class Main {

    public static void main(String[] args){
        try {
            
        Usuario usuario = new Usuario("Davi");
        usuario.conectar();
        
        Usuario usuario2 = new Usuario("Pedro");
        usuario2.conectar();


        CaixaDeMensagem msg = new CaixaDeMensagem();
        msg.enviarMensagem(usuario, usuario2, "oi, Pedro");
        msg.responderMensagem(usuario2, usuario, "oi, Davi");
        
        usuario.desconectar();
        msg.enviarMensagem(usuario, usuario2, "oi2, Pedro");
        msg.responderMensagem(usuario2, usuario, "oi2, Davi");
        
        usuario.conectar();
        usuario2.desconectar();
        
        msg.enviarMensagem(usuario, usuario2, "oi3, Pedro");
        msg.responderMensagem(usuario2, usuario, "oi3, Davi");
        
        usuario2.conectar();
        msg.enviarMensagem(usuario, usuario2, "oi4, Pedro");
        msg.responderMensagem(usuario2, usuario, "oi4, Davi");
        
        msg.enviarMensagem(usuario, usuario2, "oi5, Pedro");
        usuario.desconectar();
        msg.responderMensagem(usuario2, usuario, "oi4, Davi");
        
        

//        Requisicao req = new Requisicao();
//        req.Requisicao(usuario2, "oi ",usuario);
//        
//        Resposta res = new Resposta();
//        res.resposta(usuario, " oi, Davi",usuario2);
//        
//            System.out.println("-----------------"); 
//       
//        usuario2.desconectar();
//        Requisicao req1 = new Requisicao();
//        req.Requisicao(usuario2, "oi dnv ",usuario);
//        
//        Resposta res1 = new Resposta();
//        res.resposta(usuario2, " oi dnv, Davi",usuario);
//
//            System.out.println("-----------------"); 
//        
//        usuario2.conectar();
//        usuario.desconectar();
//        Requisicao req3 = new Requisicao();
//        req.Requisicao(usuario2, "oi ",usuario);
//        
//        Resposta res3 = new Resposta();
//        res.resposta(usuario, " oi, Davi",usuario2);       
//     
        
        
        
        
        } 
        catch (Exception ex) {
            System.out.println("Falha: " + ex.getMessage());
        }
    }
}
