/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.questao2;

import stateNew.Conexao;
import stateNew.Requisicao;
import stateNew.Resposta;
import stateNew.Usuario;



/**
 *
 * @author TgP
 */
public class Main {

    public static void main(String[] args){
        try {
            
        Usuario user1 = new Usuario("Thiago");   
        Usuario user2 = new Usuario("Vlad");
        
        Requisicao req = new Requisicao(user1,"oi");
        Resposta res = new Resposta(user2,"oi tbm");
        
        Conexao cx = new Conexao();
        cx.conectar();

        cx.enviarRequisicao(req);
        cx.receberResposta(res);
        
        Requisicao req1 = new Requisicao(user1,"oi");
        Resposta res1 = new Resposta(user2,"oi tbm");
        
        System.out.println("-------------");
        cx.enviarRequisicao(req1);
        cx.receberResposta(res1);
        
        
        System.out.println("-------------");
        cx.desconectar();
        cx.enviarRequisicao(req1);
        cx.receberResposta(res1);
        cx.conectar();
                   

        } 
        catch (Exception ex) {
            System.out.println("Falha: " + ex.getMessage());
        }
    }
}
