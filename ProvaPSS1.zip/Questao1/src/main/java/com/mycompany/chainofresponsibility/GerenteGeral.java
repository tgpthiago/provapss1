/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.chainofresponsibility;


/**
 *
 * @author TgP
 */
public class GerenteGeral extends AbstractFuncionarioHandler {
    private double limite = 1500;
    private boolean ferias = false;
    private String cargo = "Gerente Geral";
    
    @Override
    public boolean accept(Pagamento pagamento) {
        
        if(verStatus() == true){
            System.out.println(cargo +": Pagamento encaminhado pq funcionario está de ferias");
            return false;
        } 
        if (pagamento.getValor() > limite){      
            System.out.println(cargo +": Pagamento encaminhado, pois valor muito alto!");
            return false;
        }
        System.out.println(cargo +": Pagamento Realizado!");
        return true;                
    }
    
    public Boolean verStatus() {
        return ferias;
    }

    public void entrarESairFerias() {
        ferias = ferias != true;
        System.out.print(cargo + ": ");
    }

    @Override
    public void doHandle(Pagamento pagamento) {
        pagamento.setPago(true);
    }

}
