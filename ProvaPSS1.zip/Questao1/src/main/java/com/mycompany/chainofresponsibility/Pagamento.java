/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.chainofresponsibility;

/**
 *
 * @author TgP
 */
public class Pagamento {
    private double valor;
    private boolean pago = false;

    public Pagamento(double valor) {
        this.valor = valor;
    }
    
    public double getValor() {
        return valor;
            
    }
    
    public void setPago(boolean pago){
        this.pago = pago;
    }
    
    
}
