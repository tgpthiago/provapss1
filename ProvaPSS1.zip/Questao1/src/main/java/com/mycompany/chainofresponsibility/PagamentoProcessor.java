/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.chainofresponsibility;

import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author TgP
 */
public class PagamentoProcessor {
    private List<AbstractFuncionarioHandler> funcionarios;

    public PagamentoProcessor() {
       funcionarios = new ArrayList<>();
       this.funcionarios.add(new GerenteImediato());
       this.funcionarios.add(new GerenteGeral());
       this.funcionarios.add(new DiretorFinanceiro());
       this.funcionarios.add(new DiretorGeral());
    }
    
    public void processar(Pagamento pagamento){
        for(AbstractFuncionarioHandler funcionario : funcionarios){
            if(funcionario.accept(pagamento) == true){
                funcionario.doHandle(pagamento);
                break;
            }
        }
    }
}

