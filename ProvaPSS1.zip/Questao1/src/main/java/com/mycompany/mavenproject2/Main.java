
package com.mycompany.mavenproject2;

//import com.patterns.chainofresponsibility.DiretorFinanceiro;

import com.mycompany.chainofresponsibility.Pagamento;
import com.mycompany.chainofresponsibility.PagamentoProcessor;

//import com.patterns.chainofresponsibility.DiretorGeral;
//import com.patterns.chainofresponsibility.Funcionario;
//import com.patterns.chainofresponsibility.GerenteGeral;
//import com.patterns.chainofresponsibility.GerenteImediato;

/**
 *
 * @author TgP
 */
public class Main {

    public static void main(String[] args) {
        PagamentoProcessor processadora = new PagamentoProcessor();
        
        Pagamento pagamento = new Pagamento(6000);
        processadora.processar(pagamento);
    }
}
    
